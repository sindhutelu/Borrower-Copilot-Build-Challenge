const fs = require("fs");
const path = require("path");
const { JSDOM } = require("jsdom");

async function run() {
  const html = fs.readFileSync(path.join(__dirname, "../index.html"), "utf8");
  const dom = new JSDOM(html, {
    url: "file://" + path.join(__dirname, "../index.html"),
    runScripts: "dangerously",
    resources: "usable",
    pretendToBeVisual: true,
  });
  const errors = [];
  dom.window.onerror = (msg) => errors.push(msg);

  // wait for scripts to load (JSDOM loads local <script src> files async)
  await new Promise((resolve) => {
    dom.window.addEventListener("load", resolve);
    setTimeout(resolve, 2000);
  });

  const doc = dom.window.document;

  // 1. Click Priya's persona button -> should jump straight to results
  const priyaBtn = [...doc.querySelectorAll(".persona-pick button")].find(b => b.dataset.persona === "priya");
  priyaBtn.click();
  const stamp = doc.querySelector(".stamp");
  console.log("PRIYA stamp text:", stamp ? stamp.textContent.trim() : "MISSING");
  console.log("PRIYA results block present:", !!doc.querySelector(".negcard"));

  // 2. Reset and click Anita -> should say don't borrow
  doc.getElementById("btnRestart").click();
  const anitaBtn = [...doc.querySelectorAll(".persona-pick button")].find(b => b.dataset.persona === "anita");
  anitaBtn.click();
  console.log("ANITA stamp text:", doc.querySelector(".stamp").textContent.trim());

  // 3. Full manual wizard walk-through (simulate a fresh user)
  doc.getElementById("btnRestart").click();
  doc.getElementById("btnStart").click();
  let guard = 0;
  while (!doc.getElementById("wizard").classList.contains("hidden") && guard < 40) {
    guard++;
    const optButtons = doc.querySelectorAll("#qcard .opt-grid button");
    const freeInput = doc.getElementById("freeInput");
    if (optButtons.length) {
      optButtons[0].click(); // pick first option every time
    } else if (freeInput) {
      freeInput.value = freeInput.type === "number" ? "3" : "50000";
      doc.getElementById("btnNext").click();
    } else {
      break;
    }
  }
  console.log("Wizard steps taken:", guard);
  console.log("Results visible after manual walkthrough:", !doc.getElementById("results").classList.contains("hidden"));
  console.log("Manual-walkthrough stamp:", doc.querySelector(".stamp") ? doc.querySelector(".stamp").textContent.trim() : "MISSING");

  console.log("\nJS ERRORS CAUGHT:", errors.length ? errors : "none");
}

run().catch((e) => { console.error("FATAL", e); process.exit(1); });
