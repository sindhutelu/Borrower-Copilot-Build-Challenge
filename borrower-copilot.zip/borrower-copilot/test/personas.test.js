const Engine = require("../engine.js");
const { inr } = require("../rules.js");

function report(name, inputs, meta) {
  const r = Engine.run(inputs, meta);
  console.log("\n=====", name, "=====");
  console.log("Risk tier:", r.risk.tier);
  console.log("Product:", r.productInfo.product, "-", r.productInfo.why);
  console.log("O1 Verdict:", r.O1.headline, "|", r.O1.why);
  console.log("O2 Lender amount:", r.O2.lenderAmountRange.map(inr).join(" - "));
  console.log("O2 Safe amount:  ", r.O2.safeAmountRange.map(inr).join(" - "));
  console.log("O3 Rate band:", r.rateBand.map(x=>x.toFixed(1)+"%").join(" - "), "| APR:", r.aprRange.map(x=>x.toFixed(1)+"%").join(" - "));
  console.log("O4 Safe EMI ceiling:", inr(r.safeMaxEMI), "| Stress:", r.O4.stress.why);
  console.log("Confidence:", r.conf.label);
  const card = Engine.negotiationCard(inputs, r);
  console.log("Negotiation talking points:");
  card.talkingPoints.forEach(p => console.log("  -", p));
  return r;
}

// PRIYA — salaried, prime, Bengaluru
report("Priya", {
  purpose: "wedding", amountWanted: 800000, employmentType: "salaried",
  netMonthlyIncome: 110000, existingEMI: 14000, essentialExpenses: 28000 + 16000,
  age: 29, creditScoreKnown: true, creditScore: 780, bounceLast6Months: false,
  yearsStable: 5, incomeVariabilityPct: 5, emergencyFundMonths: 3,
}, { answeredOptionalCount: 3, applicableOptionalCount: 6 });

// RAVI — self-employed formal, has property collateral, no credit history
report("Ravi", {
  purpose: "business", amountWanted: 1500000, employmentType: "self_employed_formal",
  itrAnnualIncome: 420000, selfReportedMonthlyIncome: 60000, existingEMI: 0,
  essentialExpenses: 35000, age: 42, creditScoreKnown: false, bounceLast6Months: false,
  yearsStable: 14, incomeVariabilityPct: 35, hasCollateral: true, collateralType: "property",
  isProductiveUse: true, projectedIncrementalIncome: 15000,
}, { answeredOptionalCount: 5, applicableOptionalCount: 8 });

// ANITA — gig/informal, existing high-cost debt, recent bounce
report("Anita", {
  purpose: "vehicle", amountWanted: 150000, employmentType: "gig_informal",
  selfReportedMonthlyIncome: 28000, existingEMI: 0, essentialExpenses: 22000,
  age: 35, creditScoreKnown: false, bounceLast6Months: true,
  yearsStable: 2, incomeVariabilityPct: 45, emergencyFundMonths: 0,
  existingDebtOutstanding: 35000, existingDebtRatePct: 32,
  isProductiveUse: true, projectedIncrementalIncome: 6000,
}, { answeredOptionalCount: 4, applicableOptionalCount: 7 });
