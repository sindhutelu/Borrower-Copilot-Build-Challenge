const Rules = require("../rules.js");
const Engine = require("../engine.js");
const QUESTIONS = require("../questions.js");
const { inr } = Rules;

const PERSONAS = {
  "Priya, 29 — Bengaluru · salaried": { purpose: "wedding", amountWanted: 800000, employmentType: "salaried",
    netMonthlyIncome: 110000, existingEMI: 14000, essentialExpenses: 44000,
    age: 29, creditScoreKnown: "yes", creditScore: 780, bounceLast6Months: false,
    yearsStable: 5, incomeVariabilityPct: 5, emergencyFundMonths: 2 },
  "Ravi, 42 — Mysuru · self-employed": { purpose: "business", amountWanted: 1500000, employmentType: "self_employed_formal",
    itrAnnualIncome: 420000, selfReportedMonthlyIncome: 60000, existingEMI: 0,
    essentialExpenses: 35000, age: 42, creditScoreKnown: "no", bounceLast6Months: false,
    yearsStable: 14, incomeVariabilityPct: 25, hasCollateral: "property",
    isProductiveUse: true, projectedIncrementalIncome: 15000 },
  "Anita, 35 — Hubballi · informal": { purpose: "vehicle", amountWanted: 150000, employmentType: "gig_informal",
    selfReportedMonthlyIncome: 28000, existingEMI: 0, essentialExpenses: 22000,
    age: 35, creditScoreKnown: "no", bounceLast6Months: true,
    yearsStable: 2, incomeVariabilityPct: 50, emergencyFundMonths: 0,
    existingDebtOutstanding: 35000, existingDebtRatePct: 32,
    isProductiveUse: true, projectedIncrementalIncome: 6000 },
};

function finalize(r) {
  const i = Object.assign({}, r);
  i.creditScoreKnown = i.creditScoreKnown === "yes";
  if (r.hasCollateral && r.hasCollateral !== "none") { i.collateralType = r.hasCollateral; i.hasCollateral = true; }
  else { i.hasCollateral = false; i.collateralType = undefined; }
  return i;
}

function applicableQuestions(raw) {
  return QUESTIONS.filter((q) => !q.when || q.when(raw));
}

let out = "";
const p = (s = "") => (out += s + "\n");

for (const [name, raw] of Object.entries(PERSONAS)) {
  const meta = {
    applicableOptionalCount: QUESTIONS.filter((q) => q.tier === "more" && (!q.when || q.when(raw))).length,
    answeredOptionalCount: QUESTIONS.filter((q) => q.tier === "more" && (!q.when || q.when(raw)) && raw[q.id] !== undefined).length,
  };
  const inputs = finalize(raw);
  const r = Engine.run(inputs, meta);
  const card = Engine.negotiationCard(inputs, r);
  const applicable = applicableQuestions(raw);

  p(`## ${name}`);
  p();
  p(`**Asks:** ₹${raw.amountWanted.toLocaleString("en-IN")} for ${raw.purpose.replace(/_/g," ")}`);
  p();
  p("### Questions the app asked this borrower");
  p();
  p("| # | Question | Answer given |");
  p("|---|---|---|");
  applicable.forEach((q, idx) => {
    let ans = raw[q.id];
    if (ans === undefined) ans = "_(skipped)_";
    else if (typeof ans === "boolean") ans = ans ? "Yes" : "No";
    else if (q.type === "rupee") ans = "₹" + Number(ans).toLocaleString("en-IN");
    p(`| ${idx + 1} | ${q.label} | ${ans} |`);
  });
  p();
  p(`*(${meta.answeredOptionalCount} of ${meta.applicableOptionalCount} applicable tightening questions answered → confidence: **${r.conf.label}**)*`);
  p();
  p("### Outputs");
  p();
  p(`- **O1 — Verdict:** ${ {borrow:"You can go ahead", borrow_less:"Borrow less than asked", dont_borrow:"Don't borrow right now"}[r.O1.verdict] }`);
  p(`  *(${r.O1.ruleId})* ${r.O1.why}`);
  p(`- **O2 — Amount:** Lender might sanction ${inr(r.O2.lenderAmountRange[0])}–${inr(r.O2.lenderAmountRange[1])}; you can safely carry **${inr(r.O2.safeAmountRange[0])}–${inr(r.O2.safeAmountRange[1])}** — use the safe figure.`);
  if (r.O2.flipNote) p(`  ⚠️ ${r.O2.flipNote.why}`);
  p(`- **O3 — Fair rate:** ${r.rateBand[0].toFixed(1)}–${r.rateBand[1].toFixed(1)}% nominal, **${r.aprRange[0].toFixed(1)}–${r.aprRange[1].toFixed(1)}% all-in APR**, on a ${r.productInfo.product.replace(/_/g," ")}.`);
  p(`  ${r.productInfo.why}`);
  p(`- **O4 — EMI ceiling:** **${inr(r.safeMaxEMI)}/month.** ${r.O4.stress.why}`);
  p();
  p("### Negotiation Card");
  p();
  p("| | |");
  p("|---|---|");
  p(`| Ask for | ${inr(r.O2.safeAmountRange[0])}–${inr(r.O2.safeAmountRange[1])} |`);
  p(`| Fair rate | ${r.rateBand[0].toFixed(1)}–${r.rateBand[1].toFixed(1)}% |`);
  p(`| Fair all-in APR | ${r.aprRange[0].toFixed(1)}–${r.aprRange[1].toFixed(1)}% |`);
  p(`| EMI ceiling | ${inr(r.safeMaxEMI)}/month |`);
  p();
  card.talkingPoints.forEach((t) => p(`- ${t}`));
  p();
  p("---");
  p();
}

require("fs").writeFileSync(__dirname + "/../RUNTHROUGHS_generated.md", out);
console.log(out);
